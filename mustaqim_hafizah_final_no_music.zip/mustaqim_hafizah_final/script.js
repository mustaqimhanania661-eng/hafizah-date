let noCount = 0;

function nextScreen(current, next) {
  document.getElementById(current).classList.remove('active');
  document.getElementById(next).classList.add('active');
}

function runAway() {
  const noBtn = document.getElementById('noBtn');
  const yesBtn = document.getElementById('yesBtn');
  noCount++;

  const x = Math.floor(Math.random() * 180) - 90;
  const y = Math.floor(Math.random() * 100) - 50;
  noBtn.style.transform = `translate(${x}px, ${y}px)`;

  yesBtn.style.transform = `scale(${1 + noCount * 0.16})`;
  yesBtn.textContent = noCount > 3 ? 'Please say Yes 🥺❤️' : 'Yes ❤️';
}

function sayYes() {
  nextScreen('screen2', 'screen3');
  makeConfetti();
}

function confirmDate() {
  const date = document.getElementById('dateInput').value || 'Our special day';
  const time = document.getElementById('timeInput').value || 'A perfect time';
  const location = document.getElementById('locationInput').value || 'A beautiful place';

  document.getElementById('dateResult').innerHTML =
    `📅 ${date}<br>🕒 ${time}<br>📍 ${location}`;

  nextScreen('screen4', 'screen5');
  makeConfetti();
}

function createHeart() {
  const heart = document.createElement('div');
  heart.className = 'heart';
  heart.textContent = ['❤️','💕','🌸','✨','💖'][Math.floor(Math.random() * 5)];
  heart.style.left = Math.random() * 100 + 'vw';
  heart.style.animationDuration = 4 + Math.random() * 3 + 's';
  heart.style.opacity = 0.4 + Math.random() * 0.6;
  document.body.appendChild(heart);
  setTimeout(() => heart.remove(), 7000);
}

function makeConfetti() {
  for (let i = 0; i < 38; i++) {
    const c = document.createElement('div');
    c.className = 'confetti';
    c.textContent = ['🎉','❤️','✨','🌹','💕'][Math.floor(Math.random() * 5)];
    c.style.left = Math.random() * 100 + 'vw';
    c.style.top = 70 + Math.random() * 25 + 'vh';
    c.style.animationDelay = Math.random() * .5 + 's';
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 2200);
  }
}

setInterval(createHeart, 450);
