# Mustaqim Hafizah Date Website

Website romantik tanpa lagu untuk dihantar kepada Hafizah.

## Cara guna di GitHub Pages
1. Buat GitHub account.
2. Create repository baru, contoh: `date-invitation`.
3. Upload semua fail ini: `index.html`, `style.css`, `script.js`.
4. Pergi Settings > Pages.
5. Pilih Branch: `main`, folder: `/root`.
6. Tekan Save.
7. Link akan jadi seperti: `https://username.github.io/date-invitation/`

## Edit ayat
Buka `index.html` dan ubah bahagian mesej jika mahu.
